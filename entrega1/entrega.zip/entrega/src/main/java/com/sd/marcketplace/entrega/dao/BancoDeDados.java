package com.sd.marcketplace.entrega.dao;

public class BancoDeDados {

	public UsuarioDAO usuarioDAO;
	
	public BancoDeDados() {
		this.usuarioDAO = new UsuarioDAO();
	}
	
}
